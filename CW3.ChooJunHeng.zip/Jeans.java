class Jeans extends Pants {
    private boolean washable;

    public Jeans(String name,Seller seller, double price, int quantity, String size, String color, String material, double weight, double length, boolean washable) {
        super(name, seller,price, quantity, size, color, material, weight, length);
        this.washable = washable;
    }

    public Jeans() {}

    public boolean getWashable() {
        return washable;
    }

    public void setWashable(boolean washable) {
        this.washable = washable;
    }

    public void print(){
        super.print();
        System.out.printf("%-30s: %s\n","Washable",getWashable());

    }
    public void inputTwo(){
        super.inputTwo();
        System.out.println("Washable:");
        washable=Mi.inputBoolean();
    }
    @Override
    String getType() {
        return "Jeans";
    }
}