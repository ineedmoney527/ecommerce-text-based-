public interface WashingMethod {
    void setWashingMethod();
    String getWashingMethod();
    void printWashingMethod();
}
