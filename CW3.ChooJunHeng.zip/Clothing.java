//1.input One input Two
//2. transferItem method (how to get original seller)
//3. copy
abstract class Clothing implements  Cloneable{
    protected String name;
    protected double price;
    protected int quantity;
    protected String size;
    protected String color;
    protected String material;
    protected double weight;
    protected Seller seller;


    public void setMaterial(String material) {
        this.material = material;
    }



    public Clothing(String name, Seller seller,double price, int quantity, String size, String color, String material, double weight) {
        this.name = name;
        this.seller=seller;
        this.price = price;
        this.quantity = quantity;
        this.size=size;
        this.color=color;
        this.material=material;
        this.weight=weight;
    }
    public Clothing() {}

    public Clothing clone() throws CloneNotSupportedException {
        return (Clothing) super.clone();
    }

    public String getName() {
        return name;
    }
    public double getWeight() {
        return weight;
    }

    public Seller getSeller() {
        return seller;
    }

    public void setSeller(Seller seller) {
        this.seller = seller;
    }

    public String getMaterial(){
        return material;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrice(double price) {
        this.price=price;

    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getQuantity() {
        return quantity;
    }
    abstract String getType();


    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public String getColor(){
        return color;
    }
    //input for name only
    public void inputOne(){
        name=Mi.inputString("Name");}

    //input for other details after making sure no name is same
    public void inputTwo(){

        price=Mi.inputNumber("Price",false);
        quantity= (int) Mi.inputNumber("Quantity",true);
        size=Mi.inputString("Size");
        color=Mi.inputString("Color");
        material=Mi.inputString("Material");
        weight=Mi.inputNumber("Weight",false);
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void print(){
        System.out.printf("%-30s: %s\n","Name",getName());
        System.out.printf("%-30s: %s\n","Type",getType());
        System.out.printf("%-30s: %s\n","Seller", getSeller().getName());
        System.out.printf("%-30s: %d\n","Quantity",getQuantity());
        System.out.printf("%-30s: %.2f\n","Price per unit"+"("+Settings.CURRENCY+")",getPrice());
        System.out.printf("%-30s: %.2f\n","Total Price"+"("+Settings.CURRENCY+")",calculateTotalPrice());
        System.out.printf("%-30s: %s\n","Size",getSize());
        System.out.printf("%-30s: %s\n","Color",getColor());
        System.out.printf("%-30s: %s\n","Material",getMaterial());
        System.out.printf("%-30s: %.2f\n","Weight per unit",getWeight());
        System.out.printf("%-30s: %.2f\n","Total Weight",calculateTotalWeight());
    }
    public double calculateTotalWeight() {
        return weight*(double)quantity;
    }
    public double calculateTotalPrice() {return price*(double)quantity;}
}


