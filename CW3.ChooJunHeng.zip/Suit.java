class Suit extends FormalClothing implements WashingMethod {
    private String washingMethod;
    private int buttonNumber;
    private String lapelType;
    public Suit() {setWashingMethod();}

    public Suit(String name, Seller seller,double price, int quantity, String size, String color, String material, double weight , int buttonNumber,String lapelType) {
        super(name,seller, price, quantity, size, color, material, weight);
        this.buttonNumber = buttonNumber;
        this.lapelType=lapelType;
        setWashingMethod();
    }

    public int getbuttonNumber() {
        return buttonNumber;
    }

    public String getLapelType() {
        return lapelType;
    }

    public void setLapelType(String lapelType) {
        this.lapelType = lapelType;
    }

    public void setbuttonNumber(int buttonNumber) {
        this.buttonNumber = buttonNumber;
    }
    public void print(){
        super.print();
        System.out.printf("%-30s: %d\n","Button Number",getbuttonNumber());
        System.out.printf("%-30s: %s\n","Lapel Type",getLapelType());
        printWashingMethod();

    }
    public void inputTwo(){
        super.inputTwo();
        buttonNumber= (int) Mi.inputNumber("Button Number",true);
        lapelType=Mi.inputString("Lapel Type");
    }

    @Override
        String getType() {
            return "suit";
        }

    @Override
    public void setWashingMethod() {
        washingMethod="inside of a mesh laundry bag on a cold, gentle setting";

    }
    @Override
    public String getWashingMethod() {
        return washingMethod;
    }

    @Override
    public void printWashingMethod() {
        System.out.printf("%-30s: %s\n","SPECIAL WASHING METHOD",getWashingMethod());
    }
}