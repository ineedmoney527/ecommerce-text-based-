import java.util.*;

class Histo {

    static int range = Settings.RANGE_HISTOGRAM;
    static String symbol = Settings.SYMBOL_HISTOGRAM;


    public static void getHistogram(ArrayList<Double> numberlist) {
        LinkedHashMap<Integer,Integer> map = new LinkedHashMap<>(registerNumber(numberlist));
        Mi.seperator();
        System.out.println("Histogram for sellers' sales");
        Mi.seperator();
        for (int ceil :map.keySet()) {
                    int upper_bound = range * ceil;
                    int lower_bound = range * (ceil - 1)+1;


                    System.out.print(lower_bound + "-" + upper_bound+ "(" + map.get(ceil) + " seller/s): ");
                    for (int i = 1; i <= map.get(ceil); i++) {
                        System.out.print(symbol);
            }
            System.out.println();
        }
    }
    public static void test(){
        System.out.println("START HISTOGRAM TEST");
        //check num close to boundaries
        System.out.println("test 1");
        ArrayList<Double> list=new ArrayList<>(Arrays.asList(100.0,101.0,99.0,200.0,201.0,199.0));
        System.out.println("Estimated:\n51-100:2\n101-150:1\n151-200:2\n201-250:1");
        getHistogram(list);
        Mi.seperator();
        System.out.println("test 2");
        //check num far away from each other
        ArrayList<Double> list2=new ArrayList<>(Arrays.asList(1.0,40.0,500.0,460.0,602.0));
        System.out.println("Estimated:\n1-50:2\n451-500:2\n601-650:1");

        getHistogram(list2);
    }
    private static LinkedHashMap registerNumber(ArrayList<Double> array) {
        LinkedHashMap<Integer, Integer> map = new LinkedHashMap<>();
        int ceil;
        for (double num : array) {
            ceil = (int) Math.ceil( num / range);
            if (!map.containsKey(ceil)) {
                map.put(ceil, 0);
            }

            int times = map.get(ceil) + 1;
            map.put(ceil,times);
        }
        return map;
    }}
