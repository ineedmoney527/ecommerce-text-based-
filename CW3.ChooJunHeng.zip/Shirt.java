public class Shirt extends FormalClothing{
    private String collarType;
    private double sleeveLength;

    public Shirt(){}

    public Shirt(String name,Seller seller, double price, int quantity, String size, String color, String material, double weight, String collarType,double sleevelength) {
        super(name,seller, price, quantity, size, color, material, weight);
        this.collarType = collarType;
        this.sleeveLength=sleevelength;
    }

    public String getCollarType() {
        return collarType;
    }

    public void setCollarType(String collarType) {
        this.collarType = collarType;
    }

    public double getSleeveLength() {
        return sleeveLength;
    }

    public void setSleeveLength(double sleeveLength) {
        this.sleeveLength = sleeveLength;
    }

    public void print(){
        super.print();
        System.out.printf("%-30s: %s\n","Collar Type",getCollarType());
        System.out.printf("%-30s: %.2f\n","Sleeve Length",getSleeveLength());
    }
    public void inputTwo(){
        super.inputTwo();
        collarType=Mi.inputString("Collar Type");
        sleeveLength=  Mi.inputNumber("Sleeve Length",false);
    }

    @Override
    String getType() {
        return "Shirt";
    }
}
