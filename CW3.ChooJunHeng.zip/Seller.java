import java.util.ArrayList;

public class Seller extends User {
    //we are allowed to put a maximum of 5
    private ArrayList<Clothing> soldItems;

    public Seller(String name, String email, String password,String address) {
        super(name, email, password,address);
        soldItems=new ArrayList<>();
    }



    public Seller() {
        super();
    }

    public void menu(){
        while (true) {
            System.out.println("\nMenu");
            System.out.println("1. Add item to shop");
            System.out.println("2. Remove item with quantities from shop");
            System.out.println("3. Drop item from shop");
            System.out.println("4. Update item in shop");
            System.out.println("5. View shop items");
            System.out.println("6. Logout");
            System.out.println("7. Change personal details");

            int sellerOption= Mi.inputChoice("Choice",1,7);
            switch (sellerOption) {
                // add item to shop
                case 1:
                   addItemtoShop();
                    break;

//                case 2 -> {
//                    Clothing itemToRemove = selectItem();
//                    if (itemToRemove != null) {
//                        dropItem(itemToRemove, Mi.quantityPrompt(itemToRemove), getItems(), itemToRemove.getSeller().getItems());
//                    }
//                }
//
//                // Remove item (all)
//                case 3 -> {
//                    Clothing itemToDrop = selectItem();
//                    if (itemToDrop != null) {
//                        dropItem(itemToDrop, itemToDrop.getQuantity(), getItems(), itemToDrop.getSeller().getItems());
//                    }
//                }
                // remove item
                case 2:
                    Clothing itemToRemove= selectItem();
                    if (itemToRemove != null){
                        removeItem(itemToRemove,Mi.quantityPrompt(itemToRemove),getItems());
                    }
                    break;
                case 3 :
                    Clothing itemToDrop = selectItem();
                    if (itemToDrop != null) {
                        removeItem(itemToDrop,itemToDrop.getQuantity(),getItems());
                    }
                    break;
                case 4:
                    // Update item
                    Clothing itemToUpdate=selectItem();
                    if (itemToUpdate != null){
                    updateItem(itemToUpdate);}
                    break;
                case 5:
                    viewItem();
                    break;
                case 6:
                    // Logout
                    return;
                case 7:
                    updateDetail();
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        }
    }
//update details of item
    private void updateItem(Clothing item) {

        System.out.println("1. Name\n2. price\n3. size\n4. color \n5. material\n6. weight\n7. Quantity\n");
        int choice=0;
        if (item instanceof Shirt){
            choice=Mi.inputChoice("8. Collar Type\n9.Sleeve Length\n",1,9);
            if (choice==8) ((Shirt) item).setCollarType(Mi.inputString("New collar type"));
            else if(choice==9)((Shirt) item).setSleeveLength( Mi.inputNumber("New sleeve length",false));
    }else if(item instanceof  Suit){
            choice=Mi.inputChoice("8. Button Number \n9.Lapel Type\n",1,9);
            if (choice==8) ((Suit) item).setbuttonNumber((int)Mi.inputNumber("New button number",true));
            else if(choice==9)((Suit) item).setLapelType(Mi.inputString("New Label Type"));
        }else if (item instanceof TShirt){
            choice=Mi.inputChoice("8. Neck Type \n9. Logo\n",1,9);
            if (choice==8)((TShirt) item).setNeckType(Mi.inputString("New Neck type"));
            else if(choice==9)((TShirt) item).setLogo(Mi.inputString("New Logo"));
        }else if (item instanceof  Pants){
            if (item instanceof Jeans){
            choice=Mi.inputChoice("8. Length\n9. Washable\n",1,9);
                if (choice==8)((Pants) item).setLength(Mi.inputNumber("New Length",false));
            int washableChoice=Mi.inputChoice("1.Washable 2.Not washable",1,2);
                ((Jeans) item).setWashable(washableChoice == 1);
        }else if (item instanceof Chinos){
            choice=Mi.inputChoice("8. Length\n 9. Fabric\n",1,8);
                if (choice==8)((Pants) item).setLength(Mi.inputNumber("New Length",false));
            if (choice==9)((Chinos) item).setFabric(Mi.inputString("New Fabric"));
        }}
    if (choice==1){
        String newName=Mi.inputString("New Name");
        if (Mi.CompareName("name",newName,getItemNames())){
        item.setName(newName);}}
    else if(choice==2)item.setPrice(Mi.inputNumber("New Price",false));
    else if(choice==3)item.setSize((Mi.inputString("New Size")));
    else if (choice==4)item.setColor(Mi.inputString("New color"));
    else if (choice==5)item.setMaterial(Mi.inputString("New Material"));
    else if (choice==6)item.setWeight(Mi.inputNumber("New Weight",false));
    else if (choice==7)item.setQuantity((int) Mi.inputNumber("New Quantity",true));}


    public void addItemtoShop() {
        if(getItems().size()>=Settings.MAX_ITEMS){// not allow if shop exceeds predefined slots
            System.out.println("Not enough space!");
            return;
        }
        int c =  Mi.inputChoice("Choose Clothing Type:\n1. Suit\n2. Shirt\n3. T-Shirt\n4. Jeans\n5. Chinos \nChoice",1,5);
        Clothing newItem ;
        if(c==1) newItem = new Suit();
        else if(c==2) newItem = new Shirt();
        else if(c==3) newItem = new TShirt();
        else if(c==4) newItem = new Jeans();
        else newItem = new Chinos();
        newItem.inputOne();//input for name

        if(Mi.CompareName("item name",newItem.getName(),getItemNames())){//check if item with same name already exists in this shop
            newItem.setSeller(this);// set seller ( since cant be set in input)
            newItem.inputTwo();//input for other details if no same item name
            getItems().add(newItem);
            if (Settings.test)System.out.println("Item "+newItem.getName()+"("+newItem.getType()+","+newItem.getQuantity()+") is added!");
            }

    }

    public ArrayList<Clothing> getSoldItems() {
        return soldItems;
    }

    //get all names of items to be compared
    public  ArrayList<String> getItemNames(){
        ArrayList<String>names = new ArrayList<>();
        for(Clothing clothing:getItems())names.add(clothing.getName());
        return names;
    }
    //get total sales of this seller
public double getSales(){
        double total=0;
        for (Clothing item:soldItems){
            total+=item.getPrice()*item.getQuantity();
        }
return total;}


}
