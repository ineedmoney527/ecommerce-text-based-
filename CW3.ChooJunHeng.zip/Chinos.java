class Chinos extends Pants implements WashingMethod {
    private String fabric;
    private String washingMethod;
    public Chinos(String name,Seller seller, double price, int quantity, String size, String color, String material, double weight, double length, String fabric) {
        super(name,seller, price, quantity, size, color, material, weight, length);
        this.fabric = fabric;
        setWashingMethod();
    }

    public Chinos() {setWashingMethod();}

    public String getFabric() {
        return fabric;
    }

    public void setFabric(String fabric) {
        this.fabric = fabric;
    }

    public void print(){
        super.print();
        System.out.printf("%-30s: %s\n","Fabric",getFabric());
        printWashingMethod();

    }
    public void inputTwo(){
        super.inputTwo();
        fabric=Mi.inputString("Fabric");
    }


    @Override
    String getType() {
        return "Chinos";
    }

    @Override
    public void setWashingMethod() {
        washingMethod="Wash Them In Cold Water.";
    }

    @Override
    public String getWashingMethod() {
        return washingMethod;
    }

    @Override
    public void printWashingMethod() {
        System.out.printf("%-30s: %s\n","SPECIAL WASHING METHOD",getWashingMethod());
    }
}