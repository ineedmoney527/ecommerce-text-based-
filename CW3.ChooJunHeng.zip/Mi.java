import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Mi {
    public static Scanner scanner = new Scanner(System.in);
    public static double inputNumber(String prompt,boolean isInt){
        while(true) {
            System.out.print(prompt+" = ");
            try {
                double ans;
                if(!isInt){
                ans=scanner.nextDouble();}
                else{
                    ans=scanner.nextInt();
                }
                if (ans>0){
                    scanner.nextLine();
                return ans;}
                throw new Exception();// not allow negative number
            } catch (Exception e) {
                System.out.println("Invalid input, please try again");
                scanner.nextLine();
            }
        }
    }



    public static int inputChoice (String prompt,int start, int end){
        while (true){
            int choice= (int) inputNumber(prompt,true);
            if (choice>=start && choice<=end){
                if (Settings.test) System.out.println("choice "+choice+" is chosen");
                return choice;
            }else{
                System.out.println("Please input from "+start+" to "+end+" only!");
            }
        }
    }

    public static String inputString(String prompt){

        while (true){
            System.out.print(prompt+"=");
            String ans=scanner.nextLine().trim().replaceAll(" +", " ");
            if (!ans.isBlank()){
            return ans;}
            else{
                System.out.println("Empty input!Invalid.");
            }
        }
    }
    public static boolean inputBoolean(){
        while (true){
            String ans=inputString("[Y/N]").toLowerCase(Locale.ROOT);
            if (ans.equals("y")){
                return true;}
            else if (ans.equals("n")){
                return false;
            }else{
                System.out.println("Please input only 'y' or 'n' ");
            }
        }
    }
    //ask quantity of item to be added/removed
    public static int quantityPrompt(Clothing clothing) {
        int quantity;
        while (true) {
            quantity = (int) inputNumber("Quantity",true);
            if (!(quantity == 0)) {
                break;
            }
            System.out.println("Can't be 0");
        }
        if (quantity > clothing.getQuantity()) {// Check  has enough quantity of the item to
            System.out.println("Quantity is more than the available quantity!");
            return 0;
        }
        return quantity;
    }
    public static void seperator(){
        for (int i =0;i<=Settings.SEPARATOR_LENGTH;i++){
        System.out.print("-");
    }
        System.out.println();}


    //compare if same name exists
    public static boolean CompareName(String prompt,String thisName, ArrayList<String> names) {
        for (String name:names){
            if (thisName.equalsIgnoreCase(name)){
                System.out.println("Same "+prompt+" already exists!");
                return false;
            }
        }return true;}}

