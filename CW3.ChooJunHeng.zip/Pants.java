abstract class Pants extends Clothing {
    protected double length;

    public Pants() {}

    public Pants(String name, Seller seller, double price, int quantity, String size, String color, String material, double weight, double length) {
        super(name, seller, price, quantity, size, color, material, weight);
        this.length = length;
    }


    public void print() {
        super.print();
        System.out.printf("%-30s: %.2f\n", "Length (cm)", getLength());
    }

    public void inputTwo() {
        super.inputTwo();
        length = Mi.inputNumber("Length", false);
    }

    public void setLength(double length) {
        this.length = length;
    }
    public double getLength() {
        return length;
    }
}
