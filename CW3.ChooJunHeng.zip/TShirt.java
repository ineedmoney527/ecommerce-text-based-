class TShirt extends Clothing {
    private String neckType;
    private String logo;

    public TShirt(String name,Seller seller, double price, int quantity, String size, String color, String material, double weight, String neckType,String logo) {
        super(name,seller, price, quantity, size, color, material, weight);
        this.neckType = neckType;
        this.logo=logo;
    }

    public TShirt() {}

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }


    public String getNeckType() {
        return neckType;
    }

    public void setNeckType(String neckType) {
        this.neckType = neckType;
    }
    public void print(){
        super.print();
        System.out.printf("%-30s: %s\n","Neck Type",getNeckType());
        System.out.printf("%-30s: %s\n","Logo",getLogo());
    }
    public void inputTwo(){
        super.inputTwo();
        neckType=Mi.inputString("Neck Type");
        logo=  Mi.inputString("Logo");
    }

    @Override
    String getType() {
        return "T-shirt";
    }
}
