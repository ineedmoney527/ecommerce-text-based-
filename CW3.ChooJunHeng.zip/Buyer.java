import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

class Buyer extends User {

    public Buyer(String name, String email, String password,String address) {
        super(name, email, password,address);
    }

    public Buyer() {}

    public void menu() throws CloneNotSupportedException {
        while (true) {
            System.out.println("\nMenu");
            System.out.println("1. Add item to cart");
            System.out.println("2. Remove item with quantities from cart");
            System.out.println("3. Drop item from cart");
            System.out.println("4. View cart items");
            System.out.println("5. Checkout");
            System.out.println("6. Logout");
            System.out.println("7. Change personal details");
            int buyerOption = Mi.inputChoice("Choice",1,7);
            switch (buyerOption) {
                // Add item to cart
                case 1 -> buyPrompt(ecommerce.sellers);

                //remove item (with quantity)
                case 2 -> {
                    Clothing itemToRemove = selectItem();
                    if (itemToRemove != null) {
                        dropItem(itemToRemove, Mi.quantityPrompt(itemToRemove), getItems(), itemToRemove.getSeller().getItems());
                    }
                }

                // Remove item (all)
                case 3 -> {
                    Clothing itemToDrop = selectItem();
                    if (itemToDrop != null) {
                            dropItem(itemToDrop, itemToDrop.getQuantity(), getItems(), itemToDrop.getSeller().getItems());
                    }
                }
                //view cart items
                case 4 -> viewItem();
                //checkout
                case 5 -> checkOutPrompt();
                //logout
                case 6 -> {
                    // return all items to sellers
                    if (!getItems().isEmpty()) {
                        for (int i = getItems().size(); i > 0; i--) {
                            dropItem(getItems().get(i - 1), getItems().get(i - 1).getQuantity(), getItems(), getItems().get(i - 1).getSeller().getItems());
                        }
                    }
                    return;
                }
                //update personal detail
                case 7->updateDetail();

                default -> System.out.println("Invalid option.");
            }
        }
    }

    // double-confirmation and ask for discount code
    public void checkOutPrompt() throws CloneNotSupportedException {
        if (getItems().isEmpty()) {
            System.out.println("no items bought");
            return;
        }
        System.out.println("Are you sure you want to check out?");
        if(Mi.inputBoolean()){// ask if want to checkout
            System.out.println("Do you have a discount code?");
            if (Mi.inputBoolean()){// ask if have discount code
                while (true){
                if (Mi.inputString("Enter discount code").equalsIgnoreCase(Settings.DISCOUNT_CODE)){//if correct code
                    invoice(Settings.DISCOUNT_RATE);
                    break;
                }else{//if incorrect code
                    System.out.println("incorrect code");
                }
            }}else{//if no discount code
              invoice(0);
            }
        }
    }

    //pick seller, item, quantity
    public void buyPrompt(ArrayList<User> sellers) throws CloneNotSupportedException {
        int sellerChoice;
        if (!sellers.isEmpty()) {
            //pick the desired seller
            ecommerce.showUser("Sellers",sellers);
            Mi.seperator();
            sellerChoice = Mi.inputChoice("Choose a seller", 1, sellers.size());
        } else {
            System.out.println("No sellers available now");
            return ;
        }
        Seller chosenSeller= (Seller) sellers.get(sellerChoice - 1);
        Clothing itemToBuy=chosenSeller.selectItem();//pick desired item

        if (itemToBuy != null){
            buyItem(itemToBuy,Mi.quantityPrompt(itemToBuy),getItems(),itemToBuy.getSeller().getItems());
        }
    }
    public void buyItem(Clothing item,int quantity,ArrayList<Clothing>cart,ArrayList<Clothing>shop )throws CloneNotSupportedException {
        addItem(item,quantity,cart); //add item to  buyer's cart
        removeItem(item,quantity,shop);}//remove item from seller's shop

    //get total weight/cost
    public double calculateTotal(String type){
        double total = 0;
        for (Clothing item : getItems()) {
            if (Settings.test) System.out.println(total);
            if(type.equals("weight")){
            total +=item.calculateTotalWeight();}
            else if(type.equals("cost")){
                total+=item.calculateTotalPrice();
            }
            if (Settings.test) System.out.println(total);
        }
        return total;
    }

    //produce invoice after checkout
    public void invoice(int discountRate) throws CloneNotSupportedException {
        Mi.seperator();
        System.out.printf("%60s\n", "INVOICE");
        Mi.seperator();
        System.out.printf("|  %-13s  |  %-13s  |  %-13s  |  %-13s  |  %-13s  |  %-13s  |  %-13s  | \n", "No.", "Name", "Type", "Seller", "Price"+"("+Settings.CURRENCY+")", "Quantity", "Total Price");

        for (int i = 0; i < items.size(); i++) {
            Clothing item = items.get(i);
            System.out.printf("|  %-13d  |  %-13s  |  %-13s  |  %-13s  |  %-13.2f  |  %-13d  |  %-13s  |\n", i + 1, item.getName(), item.getType(), item.getSeller().getName(), item.getPrice(), item.getQuantity(), (item.calculateTotalPrice()));
        }
        Mi.seperator();
        System.out.printf("%-15s: %s\n", "Buyer", getName());
        System.out.printf("%-15s: %s\n", "Address", getAddress());
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(Settings.DATETIME_FORMAT);//format  date
        System.out.printf("%-15s: %s\n", "Order by", dtf.format(LocalDateTime.now()));
        Mi.seperator();
        System.out.println("Payment details\n");
        double itemCost = calculateTotal("cost");
        System.out.printf("%-20s: %.2f\n\n", "Total Item Cost"+"("+Settings.CURRENCY+")", itemCost);
        double totalWeight = calculateTotal("weight");
        System.out.printf("%-20s: %.2f\n\n", "Total Weight"+"("+Settings.WEIGHT_UNIT+")", totalWeight);
        System.out.printf("%-20s: %.2f\n\n", "Delivery fee"+"("+Settings.CURRENCY+")", calculateDeliveryFee(totalWeight));
        double finalCost = itemCost + calculateDeliveryFee(totalWeight);
        double tax =calculateTax(finalCost);
        System.out.printf("%-20s: %.2f\n\n", "Service tax (" + Settings.TAX_PERCENTAGE + "%)", tax);
        double discount=calculateDiscount(discountRate,finalCost);
        System.out.printf("%-20s: %.2f\n\n", "Discount  (" + discountRate + "%)", discount);
        System.out.printf("%-20s: %.2f\n\n", "Final Cost"+"("+Settings.CURRENCY+")", tax + finalCost-discount);
        System.out.println("Please bring the invoice to Lazada Center and make your payment before " + LocalDate.now().plusDays(Settings.PAYMENT_PERIOD));//get date now + X days
        System.out.println("Thank you!");
        Mi.seperator();
        System.out.println("END OF INVOICE");
        Mi.seperator();
        transferSoldItems();
    }
    public double calculateTax(double cost){
        return cost * (Settings.TAX_PERCENTAGE / 100);
    }
    public double calculateDiscount(int discountRate, double cost){
        return cost*(discountRate/100.0);
    }

    public void transferSoldItems() throws CloneNotSupportedException {
            for (int i = getItems().size(); i > 0; i--) {
                Clothing item = getItems().get(i - 1);
                Clothing clone=item.clone();
                removeItem(item,item.getQuantity(),getItems());//remove bought item from shop
                addItem(clone, clone.getQuantity(), clone.getSeller().getSoldItems());//add bought item to seller's sold itemz
            }
        }

    public static double calculateDeliveryFee(double totalWeight) {
        if(totalWeight>=20)
        {
            return 10.0;
        }
        else if(totalWeight>=15 && totalWeight<20)
        {return 7.0;
        }
        else if(totalWeight>=10 && totalWeight<15)
        {return 4.0;
        }
        else
        {
            return 0;
        }
    }
    public static void testDeliveryFee(double weight, double estimatedItemCost){
        double deliveryFee = calculateDeliveryFee(weight);
        System.out.println("WEIGHT:"+weight+"\nDELIVERY FEE:"+deliveryFee);
        passOrFail("Delivery Fee",deliveryFee,estimatedItemCost);
    }


    private static void passOrFail(String prompt,double tested,double estimated){
            if (tested==estimated) System.out.println(prompt+" test:Pass");
            else System.out.println(prompt+" test:Fail");
            System.out.println();}


    static void testing(){

        System.out.println("Starting Delivery Fee Tests");
        Mi.seperator();
        testDeliveryFee(20,10);
        testDeliveryFee(19,7);
        testDeliveryFee(15,7);
        testDeliveryFee(14,4);
        testDeliveryFee(10,4);
        testDeliveryFee(9,0);
        System.out.println("END OF TEST");
        Mi.seperator();

    }
    public static void testing2(){
        Buyer test_buyer1=new Buyer();
        Buyer test_buyer2=new Buyer();
        Buyer test_buyer3=new Buyer();
        Buyer test_buyer4=new Buyer();
        Seller test_seller=new Seller();


        Clothing clothing_price_4=new Shirt("2", test_seller, 2, 2, "1", "1", "1", 2, "1", 1);
        Clothing clothing_price_6=new Shirt("2", test_seller, 3, 2, "1", "1", "1", 2, "1", 1);
        Clothing clothing_price_10=new Shirt("2", test_seller, 5, 2, "1", "1", "1", 2, "1", 1);
        Clothing clothing_price_16=new Shirt("2", test_seller, 2, 8, "1", "1", "1", 2, "1", 1);
        Clothing clothing_price_20=new Shirt("2", test_seller, 10, 2, "1", "1", "1", 2, "1", 1);
        test_buyer1.getItems().addAll(Arrays.asList(clothing_price_4,clothing_price_6));
        test_buyer2.getItems().addAll(Arrays.asList(clothing_price_4,clothing_price_20,clothing_price_16,clothing_price_6));
        test_buyer3.getItems().addAll(Arrays.asList(clothing_price_4,clothing_price_20,clothing_price_10,clothing_price_10));
        //（BUYER 4 HAS NO ITEM)
        System.out.println("Starting Cost of Bought items test");
        Mi.seperator();
        testCost(test_buyer1,10,0.65,2);
        testCost(test_buyer2,46,2.99,9.2);
        testCost(test_buyer3,44,2.86,8.8);
        testCost(test_buyer4,0,0,0);
        System.out.println("END of test");
        Mi.seperator();

    }
    private static void testCost(Buyer buyer, double estimatedItemCost,double estimatedTax,double estimatedDiscount) {
        System.out.println("new test");
        if (buyer.getItems().isEmpty()){
            System.out.println("this buyer has no item");return;
        }
        for (int i =0;i<buyer.getItems().size();i++){
            Clothing clothing=buyer.getItems().get(i);
            System.out.println("\nItem "+(i+1));
            System.out.printf("%-15s %-15.2f\n","Price per item",clothing.getPrice());
            System.out.printf("%-15s %-15d\n","Quantity :",clothing.getQuantity());
            System.out.printf("%-15s %-15.2f\n","Total :",clothing.calculateTotalPrice());
        }
        //convert  to 2 decimals ( just for testing purpose, not needed in real program ,cause will just use printf)
        DecimalFormat df = new DecimalFormat("0.00##");
        //test method of addition of cost of items in cart
        double itemCost = Double.parseDouble(df.format(buyer.calculateTotal("cost")));
        System.out.println("Actual Total item cost:"+itemCost);
        System.out.println("Estimated result:"+estimatedItemCost);
        passOrFail("Total item cost",itemCost,estimatedItemCost);

        //test tax method
        double tax= Double.parseDouble(df.format(buyer.calculateTax(itemCost)));
        System.out.println("Actual tax:"+tax);
        System.out.println("Estimated result:"+estimatedTax);
        passOrFail("Tax",tax,estimatedTax);


        //test discount method (20%)
        double discount= Double.parseDouble(df.format(buyer.calculateDiscount(Settings.DISCOUNT_RATE,itemCost)));
        System.out.println("Actual discount:"+discount);
        System.out.println("Estimated result:"+estimatedDiscount);
        passOrFail("discount amount for buyer",discount,estimatedDiscount);
        Mi.seperator();

    }


}




