abstract class FormalClothing extends Clothing {
    protected boolean isFormal;


    public FormalClothing(String name, Seller seller,double price, int quantity, String size, String color, String material, double weight) {
        super(name, seller, price, quantity, size, color, material, weight);
        this.isFormal = true;
    }

    public FormalClothing() {}
    public void print(){
        System.out.println("-----FORMAL-----");
        super.print();

    }

}