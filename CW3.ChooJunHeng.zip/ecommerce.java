
import java.util.*;

public class ecommerce {
    static ArrayList<User> sellers;
    static ArrayList<User> buyers;


    public ecommerce(){
        sellers = new ArrayList<>();
        buyers = new ArrayList<>();
    }
    public static void main(String[] args) throws CloneNotSupportedException {
        ecommerce app=new ecommerce();
        if (Settings.test){
        Buyer.testing();
        Buyer.testing2();
        Histo.test();}


        while (true){
            app.menu();}}

     public void menu() throws CloneNotSupportedException {
        int choice =  Mi.inputChoice("\nMenu:\n1. Create account\n2. Login\n3. Delete Account\n4. View Account\n5. Statistical operations\nChoice",1,5);
        if(choice==1) createUser();
        else if (choice==2) login();
        else if (choice==3) deleteUser();
        else if (choice==4) {
            viewUser(sellers,"Seller");
            viewUser(buyers,"Buyer");
        }
        else statistics();
    }

    // to view seller/buyer along with their name, email password
    public void viewUser(ArrayList<User> users, String prompt) {
        if (!users.isEmpty()){//prevent null pointer exception
            Mi.seperator();
            System.out.println(prompt);
            Mi.seperator();
            for (int i =0;i< users.size();i++){
                System.out.println( prompt+ (i+1));
                System.out.printf("%-15s: %s\n","Name",(users.get(i).getName()));
                System.out.printf("%-15s: %s\n","Email",(users.get(i).getEmail()));
                System.out.printf("%-15s: %s\n","Password",(users.get(i).getPassword()));
                System.out.printf("%-15s: %s\n\n","Address",(users.get(i).getAddress()));
            }
        }else{
            System.out.println("No "+prompt.toLowerCase(Locale.ROOT)+" available");
        }

    }

    //to view seller/buyer with name only
    public static void showUser(String prompt,ArrayList<User> users){
        System.out.println(prompt);
        for (int i =0;i<users.size();i++){
            System.out.println((i+1)+". "+ users.get(i).getName());
        }
    }

    public void deleteUser() {
        int choice = Mi.inputChoice("To Delete:\n1. Seller\n2. Buyer\nChoice",1,2);
        ArrayList<User>users;
        String prompt;
        if (choice==1){users=sellers;prompt="Sellers";}
        else {users=buyers;prompt="Buyers";}

        if(!users.isEmpty()){
            showUser(prompt,users);
            int c =Mi.inputChoice("To Delete:",1,users.size());
            System.out.println(users.get(c-1).getName()+"has been removed");
            users.remove(c-1);
        }
    else{
            System.out.println("Nothing to be deleted!");}
    }


    //get total sales of the app
    private static ArrayList<Double> SalesList(){
        ArrayList<Double>salesList=new ArrayList<>();
        for (User user:sellers){// add all the sales to the arraylist
            if (Settings.test) System.out.println(salesList);
            Seller seller= (Seller) user;
            if (seller.getSales()!=0){
                salesList.add(seller.getSales());
            }if (Settings.test) System.out.println(salesList);}
        return salesList;
    }

    private void statistics() {
        ArrayList<Double>salesList=SalesList();
        Collections.sort(sellers,new SellerComparator());// sort the seller list according to the sales (ascending)
        if (!salesList.isEmpty()){
        Histo.getHistogram(salesList);//print histogram
            System.out.println("Most popular seller :"+sellers.get(sellers.size()-1).getName());
            System.out.println("Least popular seller :"+sellers.get(0).getName());
            System.out.printf("%s %.2f","Total sales of the users:",calculateTotalSales(salesList));
            System.out.printf("%s %.2f","Average sales of the users:",calculateAverageSales(calculateTotalSales(salesList)));
    }else{
            System.out.println("No item has been sold yet");}
    }

    private double calculateTotalSales(ArrayList<Double> salesList){
        double total=0;
        for (double sales:salesList){
            if (Settings.test) System.out.println(total);
            total+=sales;
            if (Settings.test) System.out.println(total);
        }
        return total;
    }
    private double calculateAverageSales(double total) {
        if (Settings.test) System.out.println("Total:"+total);
        if (Settings.test) System.out.println("Size"+sellers.size());
        return total/ sellers.size();
    }


    public void login() throws CloneNotSupportedException {
        int choice = Mi.inputChoice("Choose Identity:\n1. Seller\n2. Buyer\nChoice",1,2);
        String email=Mi.inputString("Email");
        String password=Mi.inputString("Password");
        User user=CheckUser(choice,email,password);
        if (user==null){
            System.out.println("Invalid id or password.");
            menu();
        }
        else if (choice==1){
            Seller seller= (Seller) user;
            System.out.println("Logged in as seller " + seller.getName());
            seller.menu();
        }
        else if (choice==2) {
            Buyer buyer = (Buyer) user;
            System.out.println("Logged in as buyer " + buyer.getName());
            buyer.menu();
    }else if (choice==3){
            exit();
        }else {
            System.out.println("Invalid option");
        }}

    private static void exit() {
        System.out.println("Exiting...");
    }

    //check if password/email matches

    public User CheckUser(int choice,String email,String password) {
        ArrayList<User> users=null;

        if (choice==1){
            users=sellers;}
        else if (choice==2){
            users=buyers;}
        for (User user : users) {
            if (Settings.test) System.out.println("input："+email+","+password);
            if (Settings.test) System.out.println("real："+user.getEmail()+","+user.getPassword());
                if (user.verifyEmail(email)&&user.verifyPassword(password)) {
                    return user;// return user if matches
        }
    }
        return null; // return null if not matches
    }


    public void createUser() {
        User user;
        int choice = Mi.inputChoice("Choose Identity:\n1. Seller\n2. Buyer\nChoice",1,2);
        if(choice==1){
            user=new Seller();
            user.userInput();
            user=new Seller(user.getName(), user.getEmail(), user.getPassword(),user.getAddress());
        }
        else {
            user=new Buyer();
            user.userInput();
            user=new Buyer(user.getName(), user.getEmail(), user.getPassword(),user.getAddress());

        }

        if((Mi.CompareName("user name",user.getName(),getUserNames()))&&Mi.CompareName("email",user.getEmail(),getUserEmail())){// check if user name already exists
            System.out.println(user.getClass().getSimpleName()+" "+user.getName()+" is created!");
            if(user instanceof Seller){
                    sellers.add(user);}
                else{buyers.add(user);}}

    }

    // get names of all sellers/buyers
    public static ArrayList<String> getUserNames(){
        ArrayList<String>names = new ArrayList<>();
        for(User seller:sellers)names.add(seller.getName());
        for(User buyer:buyers)names.add(buyer.getName());
        return names;
    }
    public static ArrayList<String> getUserEmail(){
        ArrayList<String>emails = new ArrayList<>();
        for(User seller:sellers)emails.add(seller.getEmail());
        for(User buyer:buyers)emails.add(buyer.getEmail());
        return emails;
    }


    // compare sales between sellers to sort
 class SellerComparator implements Comparator<User> {
    @Override
    public int compare(User o1, User o2) {
        Seller seller1= (Seller) o1;
        Seller seller2= (Seller) o2;
        return Double.compare(seller1.getSales(), seller2.getSales());
    }
}}
