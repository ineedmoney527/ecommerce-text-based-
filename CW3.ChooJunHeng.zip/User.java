

import java.util.ArrayList;


// Abstract base class for sellers and buyers
abstract class User {
    protected String name;
    protected String email;
    protected String password;
    protected String address;
    protected ArrayList<Clothing>items;



    public User(String name, String email, String password, String address) {
        this.name=name;
        this.email=email;
        this.password=password;
        this.address=address;
        items=new ArrayList<>();
    }

    public User() {items=new ArrayList<>();}
    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public boolean verifyPassword(String password) {
        return this.password.equals(password);
    }

    public boolean verifyEmail(String email) {
        return this.email.equals(email);
    }






    //for  seller:pick item to be updated/removed from shop
    //for buyer: pick item to be bought/removed from cart
    public Clothing selectItem(){
        viewItem();
        if (getItems().isEmpty()){
            return null;
        }
        int choice=Mi.inputChoice("Enter item number",1,getItems().size());
        if (Settings.test)System.out.println(getItems().get(choice-1).getName()+" is selected");
        return getItems().get(choice-1);
    }
    public ArrayList<Clothing> getItems(){
        return items;

    }
    public String getPassword(){
        return password;
    }
    public void userInput(){
         name=Mi.inputString("Name");
         email=Mi.inputString("email");
         password=Mi.inputString("Password");
         address=Mi.inputString("Address");
    }
    public void updateDetail(){
        int choice = Mi.inputChoice("Change:\n1. Name\n2. Password\n3.Address\nChoice = ",1,3);
        if(choice==1){String name=Mi.inputString("New Name");
            if(Mi.CompareName("user name",name,ecommerce.getUserNames())){setName(name);}
        if (Settings.test) System.out.println("New name is:"+getName());}
        else if (choice==2){setPassword(Mi.inputString("New Password"));
            if (Settings.test) System.out.println("New password is:"+getPassword());
        }else {setAddress(Mi.inputString("Address"));
            if (Settings.test) System.out.println("New name is:" + getAddress());
        }
    }


    //1. add item to be bought to cart
    //2.  add item back to shop (when user drop item from cart)
    public void addItem(Clothing item,int quantity,ArrayList<Clothing>items) throws CloneNotSupportedException {


        boolean similar=false;
        //check if item with same name and seller exist
        for (Clothing clothing :items) {
            if (clothing.getName().equalsIgnoreCase(item.getName())&&clothing.getSeller().equals(item.getSeller())) {
                //if exist,the item's quantity increases (stack)
                similar=true;
                if (Settings.test) System.out.println(clothing.getQuantity());
                clothing.setQuantity(quantity + clothing.getQuantity());//
                if (Settings.test) System.out.println(clothing.getQuantity());
                break;
            }
        }
        //if not exist, add a new item
        if(!similar){
            Clothing clone=item.clone();// create copy of the chosen item ( so not all quantity will be added)
            clone.setQuantity(quantity);// set the quantity to be removed/added
            items.add(clone);

        }
        if (Settings.test )System.out.println(item.getName()+"("+quantity+") has been added to this cart/shop");
        }

        //1. remove item from shop if user add to cart
    //3. remove item from cart if user drops.
    //4. remove item from cart if checkout by user

    public void removeItem(Clothing item, int quantity,ArrayList<Clothing> items) {
        // Find the index of the item
        int index = items.indexOf(item);
        // Update the quantity of the item in the seller's items
        if (Settings.test) System.out.println(items.get(index).getQuantity());
        if (Settings.test)System.out.println(item.getName()+"("+quantity+")"+" has been removed from this cart/shop");
        items.get(index).setQuantity(items.get(index).getQuantity() - quantity);
        if (Settings.test) System.out.println(items.get(index).getQuantity());
        if (items.get(index).getQuantity()<=0){
            if (Settings.test)System.out.println(items.get(index).getName()+" has been remvoed completely from this shop/cart!");
            items.remove(index);

        }
    }

    //1. from cart to shop
    //2. from shop to cart
    public void dropItem(Clothing item, int quantity,ArrayList<Clothing> cart,ArrayList<Clothing>shop) throws CloneNotSupportedException {
        addItem(item,quantity,shop);
        removeItem(item,quantity,cart);
      }


    public void viewItem(){
        System.out.print(getName()+" 's ");
        if (this instanceof Buyer) System.out.print("Cart\n");
        else{
            System.out.print("Shop\n");}
        Mi.seperator();
        if (getItems().isEmpty()){
            System.out.println("Empty!");
            return;
        }
        for (int i =0;i< getItems().size();i++){
            System.out.println();
            System.out.println("Item "+(i+1)+"\n");
            getItems().get(i).print();
        }
    }

}