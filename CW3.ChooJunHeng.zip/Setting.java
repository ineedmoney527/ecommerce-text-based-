class Settings{
    //we put all settings here for convenience
    public static final String SYMBOL_HISTOGRAM = "#";
    public static final int RANGE_HISTOGRAM = 50;
    public static final int SEPARATOR_LENGTH = 150;
    public static final int PAYMENT_PERIOD = 5;//(DAYS)
    public static final String DATETIME_FORMAT="yyyy-MM-dd HH:mm:ss";
    public static final double TAX_PERCENTAGE  = 6.5;
    public static final String DISCOUNT_CODE = "ILOVEJAVA";
    public static final String CURRENCY = "RM";
    public static final String WEIGHT_UNIT = "G";
    public static final int DISCOUNT_RATE = 20;
    public static final int MAX_ITEMS= 5;
    static boolean test=false;
}